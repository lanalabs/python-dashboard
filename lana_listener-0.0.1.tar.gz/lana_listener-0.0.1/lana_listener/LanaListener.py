# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class LanaListener(Component):
    """A LanaListener component.
ExampleComponent is an example component.
It takes a property, `label`, and
displays it.
It renders an input with the property `value`
which is editable by the user.

Keyword arguments:
- id (string; optional): The ID used to identify this component in Dash callbacks.
- lana_api_key (string; default ''): API key of the current user, e.g. "API-Key asdfasd...".
- lana_log_id (string; default ''): Log ID of the currently selected log.
- lana_trace_filter_sequence (string; default '[]'): Current tracefiltersequence."""
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, lana_api_key=Component.UNDEFINED, lana_log_id=Component.UNDEFINED, lana_trace_filter_sequence=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'lana_api_key', 'lana_log_id', 'lana_trace_filter_sequence']
        self._type = 'LanaListener'
        self._namespace = 'lana_listener'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'lana_api_key', 'lana_log_id', 'lana_trace_filter_sequence']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(LanaListener, self).__init__(**args)
